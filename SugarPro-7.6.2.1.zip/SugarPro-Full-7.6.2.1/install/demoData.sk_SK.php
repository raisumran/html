<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * Obsah tohto súboru je predmetom obchodnej dohody 
 * SugarCRM Enterprise Subscription Agreement ("Licencie"), 
 * ktorá je k dispozícii na adrese:
 * http://www.sugarcrm.com/crm/products/sugar-enterprise-eula.html
 * Pri inštalácii alebo pri používaní tohto súboru musíte bezpodmienečne súhlasiť
 * s podmienkami Licencie a nesmiete použiť tento súbor inak, než je uvedené  
 * v Licenčných podmienkach.  Podľa podmienok licencie nesmiete, okrem iného: 
 * 1) poskytovať sublicencie, predávať, prenajímať ďalej rozširovať, priradiť
 * alebo inak previesť Vaše práva k softvéru a 
 * 2) použiť softvér na zdieľanie alebo účely služby, kancelárie, ako je hosťovanie 
 * Softvéru pre komerčný zisk a / alebo v prospech tretej osoby. Používanie softvéru
 * môže byť predmetom príslušných poplatkov a používanie softvéru bez zaplatenia 
 * príslušných poplatkov je striktne zakázané. Nemáte právo 
 * odstrániť autorské práva SugarCRM - copyrights zo zdrojového kódu 
 * alebo užívateľského rozhrania.
 *
 * Všetky kópie chráneného kódu musia obsahovať na každej obrazovke užívateľského rozhrania: 
 *  (i) logo s titulkom "Powered by SugarCRM" 
 *  (ii) a autorské práva SugarCRM copyright
 * v rovnakej forme, aká je použitá v distribúcii. Viac informácií k splneniu požiadaviek
 * nájdete v plnej Licencii.
 *
 * Vaše záruky, obmedzenia zodpovednosti a odškodnenia sú výslovne uvedené v licencii. 
 * Pozrite sa licenciu vo svojom jazyku, hlavne tieto práva a obmedzenia v rámci licencie. 
 * Časti vytvoril SugarCRM sú Copyright (C) 2004-2011 SugarCRM, Inc 
 * Všetky práva vyhradené. 
 * Preklad do slovenčiny Slavomír Piar (C) 2011, slapia@mvplus.info
 ********************************************************************************/
